import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

interface NavbarProps {
  selectedTab: string;
  setSelectedTab: (tab: string) => void;
}

const Navbar = ({ selectedTab, setSelectedTab }: NavbarProps) => {

  const location = useLocation();

  const navLinks = [
    { path: '/', name: 'Habit List', id: 'list', isVisible: true },
    { path: '/add-habit', name: 'Add Habit', id: 'add', isVisible: !(location.pathname.includes('/habit/')) }
  ];

  return (
    <nav className='mt-50'>
      <ul>
        {navLinks.map((link) => (
          <li className={selectedTab === link.id ? 'selected' : ''} onClick={() => setSelectedTab(link.id)}>
            {link.isVisible && <Link to={link.path}>{link.name}</Link>}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navbar;
