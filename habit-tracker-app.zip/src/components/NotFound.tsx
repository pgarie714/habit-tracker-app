const NotFound = () => {
  return (
    <div className="not-found">404 - Page not found!</div>
  );
};

export default NotFound;
