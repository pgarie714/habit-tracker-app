import { render, screen } from '@testing-library/react';
import HabitTable from './HabitTable';

const onDeleteHabitMock = jest.fn();

describe('HabitTable component', () => {
  it('renders "No Habits Found!" when habits array is empty', () => {
    render(<HabitTable habits={[]} onDeleteHabit={onDeleteHabitMock} />);
    
    const noHabitsRow = screen.getByText('No Habits Found!');
    
    expect(noHabitsRow).toBeInTheDocument();
  });
});
