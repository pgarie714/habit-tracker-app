import { render, screen } from '@testing-library/react';
import Navbar from './Navbar';
import { MemoryRouter } from 'react-router-dom';

describe('Header component', () => {
    it('renders Header component', () => {
        render(<MemoryRouter><Navbar selectedTab={'link'} setSelectedTab={jest.fn()} /></MemoryRouter>
        );
        expect(screen.getByText('Habit List')).toBeInTheDocument();
    });
});