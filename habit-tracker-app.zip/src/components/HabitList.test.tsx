import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import HabitList from './HabitList';

describe('HabitForm component', () => {
    const habits = [
        { id: '1', name: 'Exercise', frequency: 'Daily', completed: 'completed' },
        { id: '2', name: 'Read', frequency: 'Weekly', completed: 'not-completed' },
    ];

    const onDeleteHabitMock = jest.fn();

    it('renders HabitForm component', () => {
        render(
            <MemoryRouter>
                <HabitList habits={habits} onDeleteHabit={onDeleteHabitMock} />
            </MemoryRouter>
        );
        expect(screen.getByText('Logged Habits')).toBeInTheDocument();
    });
});