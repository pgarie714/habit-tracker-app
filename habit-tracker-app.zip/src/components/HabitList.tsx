import { Typography } from '@mui/material';
import HabitTable from './HabitTable';
import { Habit } from '../App';

interface HabitListProps {
  habits: Habit[];
  onDeleteHabit: (id: string) => void;
}

const HabitList = ({ habits, onDeleteHabit }: HabitListProps) => {
  return (
    <div className="habit-list-container">
      <Typography variant="h5" gutterBottom className="habit-list-title">
        Logged Habits
      </Typography>
      <div className="habit-cards-container">
        <HabitTable habits={habits} onDeleteHabit={onDeleteHabit}/>
      </div>
    </div>
  );
};

export default HabitList;
