import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Habit } from '../App';
import { Link } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import '../App.css';
import Tooltip from '@mui/material/Tooltip';

interface HabitTableProps {
    habits: Habit[];
    onDeleteHabit: (id: string) => void;
}

export default function HabitTable({ habits, onDeleteHabit }: HabitTableProps) {
    return (
        <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
                <TableHead>
                    <TableRow>
                        <TableCell align="center">Name</TableCell>
                        <TableCell align="center">Frequency</TableCell>
                        <TableCell align="center">Status</TableCell>
                        <TableCell align="center"></TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {habits.map((row: Habit) => (
                        <TableRow
                            key={row.name}
                        >
                            <TableCell align="center">{row.name}</TableCell>
                            <TableCell align="center">{row.frequency}</TableCell>
                            <TableCell align="center" className={row.completed === 'completed' ? 'completed-color': ''}>{row.completed === 'completed' ? 'Completed' : 'Not Completed'}</TableCell>
                            <TableCell align="center">
                                <Tooltip title="Edit"><Link to={`/habit/${row.id}`} className="view-details-link">
                                    <EditIcon />
                                </Link></Tooltip>
                                <Tooltip title="Delete"><DeleteIcon onClick={() => onDeleteHabit(row.id)} /></Tooltip>
                            </TableCell>
                        </TableRow>
                    ))}
                    {habits.length === 0 && (
                        <TableRow>
                        <TableCell align="center" colSpan={4}>No Habits Found!</TableCell>
                    </TableRow>
                    )}
                </TableBody>
            </Table>
        </TableContainer>
    );
}
