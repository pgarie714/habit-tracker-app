import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Habit } from '../App';
import DeleteIcon from '@mui/icons-material/Delete';
import { FormControl, MenuItem, Select, SelectChangeEvent } from '@mui/material';
import SaveIcon from '@mui/icons-material/Save';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import { idGenerator } from '../utils/utils';

interface HabitFormProps {
  habits?: Habit[];
  onDeleteHabit?: (id: string) => void;
  onSubmit?: (habit: Habit) => void;
  onEdit?: (habit: Habit) => void;
}

const HabitForm = ({ habits, onDeleteHabit, onSubmit, onEdit }: HabitFormProps) => {

  const navigate = useNavigate();

  const { id } = useParams<{ id: string }>();
  const habit: Habit = habits?.find((habit: Habit) => habit.id === id) || { id: '0', name: '', frequency: '', completed: 'not-completed' };

  const [formData, setFormData] = useState({ name: habit?.name || '', frequency: habit?.frequency || '', completed: habit?.completed || 'not-completed' })
  const [isFormIncomplete, setIsFormIncomplete] = useState(false);

  const handleFormChange = (event: React.ChangeEvent<HTMLInputElement> | SelectChangeEvent) => {
    setIsFormIncomplete(false);
    setFormData((formData)=> {
      return {
        ...formData,
        [event.target.name]: event.target.value
      }
    });
  }

  const handleSubmit = () => {
    if(formData.name === '' || formData.frequency === '') {
      setIsFormIncomplete(true);
      return;
    }
    onSubmit?.({ id: idGenerator(), name: formData.name, frequency: formData.frequency, completed: formData.completed } as Habit);
    setFormData({name: '', frequency: '', completed: 'not-completed'});
    navigate('/');
  };

  const handleEdit = () => {
    if(formData.name === '' || formData.frequency === '') {
      setIsFormIncomplete(true);
      return;
    }
    onEdit?.({id, name: formData.name, frequency: formData.frequency, completed: formData.completed} as Habit);
    navigate('/');
  }

  return (
    <Card sx={{ minWidth: 275 }}>
      <CardContent>
        <Typography variant="body2">
          {isFormIncomplete && <div className='error'>All the fields are mandatory, please fill them.</div>}
          <table>
            <tr>
              <td>Habit Name</td>
              <td>
                <input type="text" name="name" value={formData.name} className={isFormIncomplete && formData.name === '' ? 'input-error' : ''} onChange={handleFormChange} />
              </td>
            </tr>
            <tr>
              <td>Frequency</td>
              <td>
                <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                  <Select
                    labelId="frequency-select-label"
                    id="frequency-select"
                    value={formData.frequency}
                    name="frequency"
                    onChange={handleFormChange}
                    error={isFormIncomplete && formData.frequency === ''}
                  >
                    <MenuItem value={''} disabled>---Select---</MenuItem>
                    <MenuItem value={'Daily'}>Daily</MenuItem>
                    <MenuItem value={'Weekly'}>Weekly</MenuItem>
                    <MenuItem value={'Monthly'}>Monthly</MenuItem>
                  </Select>
                </FormControl>
              </td>
            </tr>
            <tr>
              <td>Status</td>
              <td><FormControl sx={{ m: 1, minWidth: 120 }} size="small">
                <Select
                  labelId="completed-select-label"
                  id="completed-select"
                  value={formData.completed}
                  name="completed"
                  onChange={handleFormChange}
                >
                  <MenuItem value={''} disabled>---Select---</MenuItem>
                  <MenuItem value={'completed'}>Completed</MenuItem>
                  <MenuItem value={'not-completed'}>Not Completed</MenuItem>
                </Select></FormControl></td>
            </tr>
          </table>
        </Typography>
      </CardContent>
      <CardActions className='card-actions'>
        {onDeleteHabit && <Tooltip title="Delete"><DeleteIcon data-testid="delete" onClick={() => { navigate('/'); onDeleteHabit(habit.id) }} /></Tooltip>}
        <Tooltip title="Save" onClick={onDeleteHabit ? handleEdit : handleSubmit}><SaveIcon data-testid="save"/></Tooltip>
      </CardActions>
    </Card>
  );
};

export default HabitForm;

