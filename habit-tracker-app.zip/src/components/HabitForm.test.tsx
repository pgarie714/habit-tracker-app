import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import HabitForm from './HabitForm';

describe('HabitForm component', () => {
    const habits = [
        { id: '1', name: 'Exercise', frequency: 'Daily', completed: 'completed' },
        { id: '2', name: 'Read', frequency: 'Weekly', completed: 'not-completed' },
    ];

    const onDeleteHabitMock = jest.fn();
    const onSubmitMock = jest.fn();
    const onEditMock = jest.fn();

    it('renders HabitForm component', () => {
        render(
            <MemoryRouter>
                <HabitForm habits={habits} onDeleteHabit={onDeleteHabitMock} onSubmit={onSubmitMock} onEdit={onEditMock} />
            </MemoryRouter>
        );
    });

    it('should have form elements', () => {
        render(
            <MemoryRouter>
                <HabitForm habits={habits} onDeleteHabit={onDeleteHabitMock} onSubmit={onSubmitMock} onEdit={onEditMock} />
            </MemoryRouter>
        );

        expect(screen.getByText('Habit Name')).toBeInTheDocument();
        expect(screen.getByText('Frequency')).toBeInTheDocument();
        expect(screen.getByText('Status')).toBeInTheDocument();
        expect(screen.getByTestId('save')).toBeInTheDocument();
        expect(screen.getByTestId('delete')).toBeInTheDocument();
    });
});