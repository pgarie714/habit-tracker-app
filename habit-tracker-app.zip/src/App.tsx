import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HabitList from './components/HabitList';
import HabitForm from './components/HabitForm';
import Navbar from './components/Navbar';
import './App.css';
import { initialHabits } from './utils/utils';
import NotFound from './components/NotFound';
import Header from './components/Header';

export interface Habit {
  id: string;
  name: string;
  frequency: string;
  completed: string;
}

const App: React.FC = () => {

  const [habits, setHabits] = useState<Habit[]>(initialHabits);
  const [selectedTab, setSelectedTab] = useState(window.location.pathname.includes('add-habit') ? 'add' : 'list');

  const handleFormSubmit = (habit: Habit) => {
    setHabits((prevHabits) => [...prevHabits, habit]);
    setSelectedTab('list');
  };

  const handleHabitEdit = (habit: Habit) => {
    setHabits((habits) => habits.map((curr) => {
      if (curr.id === habit.id) {
        return habit;
      } else {
        return curr;
      }
    }));
    setSelectedTab('list');
  }

  const deleteHabit = (id: string) => {
    const newHabits = habits.filter((habit: Habit) => habit.id !== id);
    setHabits(newHabits);
    setSelectedTab('list');
  }

  return (
    <Router>
      <div className="App">
        <Header />
        <Navbar selectedTab={selectedTab} setSelectedTab={setSelectedTab} />
        <Routes>
          <Route path="/" element={<HabitList habits={habits} onDeleteHabit={deleteHabit} />} />
          <Route path="/habit/:id" element={<HabitForm habits={habits} onDeleteHabit={deleteHabit} onEdit={handleHabitEdit} />} />
          <Route path="/add-habit" element={<HabitForm onSubmit={handleFormSubmit} />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
