export const idGenerator = () => {
  var S4 = function () {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
  };
  return (
    S4() +
    S4() +
    "-" +
    S4() +
    "-" +
    S4() +
    "-" +
    S4() +
    "-" +
    S4() +
    S4() +
    S4()
  );
};

export const initialHabits = [
  { id: "1", name: "Exercise", frequency: "Daily", completed: "not-completed" },
  { id: "2", name: "Read", frequency: "Weekly", completed: "completed" },
];
